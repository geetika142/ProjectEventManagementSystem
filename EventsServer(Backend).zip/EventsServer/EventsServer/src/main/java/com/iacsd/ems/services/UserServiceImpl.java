package com.iacsd.ems.services;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iacsd.ems.daos.EventsDao;
import com.iacsd.ems.daos.UserDao;
import com.iacsd.ems.daos.UserRatingsDao;
import com.iacsd.ems.dtos.CredentialsUser;
import com.iacsd.ems.dtos.DtoEntityConverter;
import com.iacsd.ems.dtos.EventsDTO;
import com.iacsd.ems.dtos.RatingsDTO;
import com.iacsd.ems.entities.Events;
import com.iacsd.ems.entities.User;
import com.iacsd.ems.entities.UserRatings;

@Transactional
@Service
public class UserServiceImpl {
	@Autowired
	private EventsDao eventsDao;
	@Autowired
	private UserRatingsDao userRatingsDao;
	@Autowired
	private DtoEntityConverter converter;
	
	@Autowired
	private UserDao userDao;


	public User signin(CredentialsUser cred) {
		User user=userDao.getUserByEmail(cred.getEmail());
		if(user.getPassword().equals( cred.getPassword()))
			return user;
		else
			return null;
		
	}
	public User signup(User user) {
		user.setRole("user");
		return userDao.save(user);
	}
	
	public List<Events> findEventsById(int userid){
		return	eventsDao.findEventsByUserid(userid);
		 	
	}
	
	public UserRatings addRatingsAndFeedBack(RatingsDTO ratingsdto){
		UserRatings ratings = converter.toRatingsEntity(ratingsdto);
//		ratings = userRatingsDao.dataSaving(ratings.getUserid(),ratings.getRatings(),ratings.getFeedback());
//		return Collections.singletonMap("insertedId", ratings.getRatingid());
		
		return userRatingsDao.save(ratings);
	}
	

}
