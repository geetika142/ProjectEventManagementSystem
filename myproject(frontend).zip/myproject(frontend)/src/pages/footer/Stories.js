const Stories = () => {
    return (
        <>
         <h2 style={{ 'text-align': 'center' }}><b>Success Stories</b></h2>
    
         <h3 style={{ 'text-align': 'center',color:'white',marginLeft:'20%',marginRight: '20%' }}>
             We are just getting started...
         </h3>
        </>
    
    );
    };
    
    export default Stories;