const About = () => {
return (
    <>
     <h2 style={{ 'text-align': 'center' }}><b>ABOUT</b></h2>

     <h3 style={{ 'text-align': 'justify',color:'white',marginLeft:'20%',marginRight: '20%' }}>An event management site for users through which a user can view, select and book events, a vendor can signup with us,
and an admin can manage the vendors.</h3>
    </>

);
};

export default About;