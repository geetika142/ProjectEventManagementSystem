const OrderData = [
    {
        
        eventid:1,
        venue:"Pride",
        category: "Birthday",
        capacity: 450,
        duration:"3 Days",
        amount:1500000,
        ratings:4.2,
        feedback:"very good improve dj",
 
    },
    // {
    //     eventid:2,
    //     venue:"R7",
    //     category: "Conference",
    //     capacity: 150,
    //     duration:"2 Days",
    //     amount:150000,
    //     ratings:4.0,
    //     feedback:"improve catering",
    
    // },
    // {
     
    //     eventid:3,
    //     venue:"Tuli",
    //     category: "Wedding",
    //     capacity: 650,
    //     duration:"7 Days",
    //     amount:2000000,
    //     ratings:4.5,
    //     feedback:"improve dj",
    
    // },
    // {
    //     eventid:4,
    //     venue:"AjentJacx",
    //     category: "Birthday",
    //     capacity: 40,
    //     duration:"1 Days",
    //     amount:15000,
    //     ratings:3.8,
    //     feedback:"food not good",
    
    // },
  
   
  ];
  
  export default OrderData;
  