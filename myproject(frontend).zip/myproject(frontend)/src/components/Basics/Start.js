import React from "react";
import SearchForm from "./SearchForm";

import "./style.css";
const Start = () => {
  return (
    <> 
     <SearchForm/>
     
    </>
  );
};

export default Start;
