const Menu = [
  {
    id: 1,
    image: "images/testimg.jpg",
    name: "venue1",
    category: "Wedding",
    price: "12₹",
    capacity:"500",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in .  ",
  },

  {
    id: 2,
    image: "images/testimg.jpg",
    name: "venue2",
    category: "Birthday",
    price: "20₹",
    capacity:"600",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in .  ",
  },
  {
    id: 3,
    image: "images/testimg.jpg",
    name: "venue3",
    category: "Conference",
    price: "10₹",
    capacity:"700",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 4,
    image: "../images/testimg.jpg",
    name: "venue4",
    category: "Fest",
    price: "50₹",
    capacity:"100",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 5,
    image: "../images/testimg.jpg",
    name: "venue5",
    category: "Fest",
    price: "80₹",
    capacity:"300",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 6,
    image: "../images/testimg.jpg",
    name: "venue6",
    category: "Wedding",
    price: "180₹",
    capacity:"400",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 7,
    image: "../images/testimg.jpg",
    name: "venue7",
    category: "Conference",
    price: "60₹",
    capacity:"800",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 8,
    image: "../images/testimg.jpg",
    name: "venue8",
    category: "Birthday",
    price: "60₹",
    capacity:"200",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 9,
    image: "../images/testimg.jpg",
    name: "venue9",
    category: "Wedding",
    price: "10₹",
    capacity:"350",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
];

export default Menu;
