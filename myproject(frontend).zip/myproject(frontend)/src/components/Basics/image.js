
const Images = [
    {
     
        id:1,
        image: "images/1.jpg",
    
    },
    {
     
        id:2,
        image: "images/2.jpg",
    
    },
    {
     
        id:3,
        image: "images/3.jpg",
    
    },
    {
     
        id:4,
        image: "images/4.jpg",
    
    },
    {
     
        id:5,
        image: "images/5.jpg",
    
    },
  
   
  ];
  
  export default Images;
  